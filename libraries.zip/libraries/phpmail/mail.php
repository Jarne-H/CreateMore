<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>PHPMailer Test</title>
</head>

<body>
    <div style="width: 640px; font-family: Arial, Helvetica, sans-serif; font-size: 11px;">
        <h1>This is a test of PHPMailer.</h1>
        <div>
            <a href="https://github.com/PHPMailer/PHPMailer/"><img src="images/phpmailer.png" height="90" width="340" alt="PHPMailer rocks"></a>
        </div>
        <p>This example uses <strong>HTML</strong>.</p>
        <p>ISO-8859-1 text: ���������</p>
    </div>
</body>

</html>